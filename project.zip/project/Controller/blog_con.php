<?php

require_once __DIR__ . '/../config.php';

class blogCon{

    private $tab_name;

    public function __construct($tab_name){
        $this->tab_name = $tab_name;
    }

    public function getBlog($id)
    {
        $sql = "SELECT * FROM $this->tab_name WHERE id_blog = $id";
        $db = config::getConnexion();

        try {
            $query = $db->prepare($sql);
            $query->execute();
            $voyage = $query->fetch();
            return $voyage;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    public function listBlogs()
    {
        $sql = "SELECT * FROM $this->tab_name";

        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Error:' . $e->getMessage());
        }
    }

    function addBlog($blog)
    {
        $sql = "INSERT INTO $this->tab_name(image_blog, nom_blog, type_blog, description_blog, date_blog) VALUES (:image, :nom, :type, :description, :date)";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute(
               [
                'image' => $blog->get_image(),
                'nom' => $blog->get_nom(),
                'type' => $blog->get_type(),
                'description' => $blog->get_description(),
                'date' => $blog->get_date()
               ]
            );
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }

    function updateBlog($blog, $id)
    {
        try {
            $db = config::getConnexion();
            $query = $db->prepare("UPDATE $this->tab_name SET image_blog = :image, nom_blog = :nom, type_blog = :type, description_blog = :description, date_blog = :date WHERE id_blog = :id");
            $query->execute([
                'id' => $id, 
                'image' => $blog->get_image(),
                'nom' => $blog->get_nom(),
                'type' => $blog->get_type(),
                'description' => $blog->get_description(),
                'date' => $blog->get_date()
            ]);
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
            echo($e);
        }
    }

    function updateBlogWithoutImg($blog, $id)
    {
        try {
            $db = config::getConnexion();
            $query = $db->prepare("UPDATE $this->tab_name SET nom_blog = :nom, type_blog = :type, description_blog = :description, date_blog = :date WHERE id_blog = :id");
            $query->execute([
                'id' => $id, 
                'nom' => $blog->get_nom(),
                'type' => $blog->get_type(),
                'description' => $blog->get_description(),
                'date' => $blog->get_date()
            ]);
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
            echo($e);
        }
    }

    function deleteBlog($id)
    {
        $sql = "DELETE FROM $this->tab_name WHERE id_blog = :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $id);

        try {
            $req->execute();
        } catch (Exception $e) {
            die('Error:' . $e->getMessage());
        }
    }


    function generateBlogs($blog) {

       
        $db = config::getConnexion();
        // Fetch data from PDOStatement object and convert it into an array
        $blogPosts = $blog->fetchAll(PDO::FETCH_ASSOC);

        echo '<div id="main" class="col-md-12">';
        for ($i = 0; $i < count($blogPosts); $i++) {
            $blogId = $blogPosts[$i]['id_blog'];
            echo '<div class="blog-card-row" style="display: flex; align-items: stretch; margin-bottom: 40px; background: #fff; border-radius: 16px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); overflow: hidden;">';
            // IMAGE COLUMN
            echo '<div class="blog-card-image" style="flex: 0 0 220px; display: flex; align-items: center; justify-content: center; background: #f5f7fa;">';
            echo '<img src="data:image/jpeg;base64,' . base64_encode($blogPosts[$i]['image_blog']) . '" alt="Blog Photo" style="width: 180px; height: 180px; object-fit: cover; border-radius: 12px; margin: 20px;">';
            echo '</div>';
            // TEXT COLUMN
            echo '<div class="blog-card-content" style="flex: 1 1 0; padding: 24px 32px; display: flex; flex-direction: column; justify-content: center;">';
            echo '<h4 style="margin-bottom: 8px;"><a href="#" style="color: #3580BB; text-decoration: none;">' . $blogPosts[$i]['type_blog'] . ' : ' . $blogPosts[$i]['nom_blog'] . '</a></h4>';
            echo '<p style="margin-bottom: 16px; color: #444;">'. $blogPosts[$i]['description_blog'] . '</p>';
            echo '<div class="blog-meta" style="font-size: 14px; color: #888; margin-bottom: 8px;">';
            echo '<span class="blog-meta-author">By: <a href="#" style="color: #3580BB;">tripped</a></span>';
            echo '<span style="margin-left: 20px;">' . $blogPosts[$i]['date_blog'] . '</span>';
            echo '</div>';
            echo '</div>';
            // COMMENTS COLUMN
            echo '<div class="blog-card-comments" style="flex: 0 0 320px; background: #f9fafb; border-left: 1px solid #eee; padding: 24px 20px; display: flex; flex-direction: column; justify-content: flex-start;">';
            // Fetch comments for this blog
            $sql_comments = "SELECT * FROM commentaire WHERE id_blog = :id_blog ORDER BY date_commentaire DESC";
            $stmt_comments = $db->prepare($sql_comments);
            $stmt_comments->execute(['id_blog' => $blogId]);
            $comments = $stmt_comments->fetchAll(PDO::FETCH_ASSOC);
            // Comments List
            echo '<div class="comments-list" style="margin-bottom: 16px;">';
            echo '<div style="font-weight: bold; color: #3580BB; margin-bottom: 8px;">Comments</div>';
            if (count($comments) > 0) {
                foreach ($comments as $comment) {
                    echo '<div style="font-size: 13px; color: #555; margin-bottom: 10px; background: #fffbe6; border-radius: 8px; padding: 8px 12px;">';
                    echo '<div style="margin-bottom: 4px; display: flex; align-items: center; justify-content: space-between;">';
echo '<span><span style="font-weight:bold; color:#3580BB;">' . htmlspecialchars($comment['auteur_commentaire'] ?? 'Anonymous') . '</span> <span style="color:#aaa; font-size:12px;">' . $comment['date_commentaire'] . '</span></span>';
echo '<a href="../gestion_comment/delete_comment.php?id=' . $comment['id_commentaire'] . '" onclick="return confirm(\'Are you sure you want to delete this comment?\');" style="margin-left:8px; color:#fff; background:#e74c3c; border:none; border-radius:4px; padding:2px 8px; font-size:12px; text-decoration:none; display:inline-block;">Delete</a>';
echo '<a href="../gestion_comment/update_comment.php?id=' . $comment['id_commentaire'] . '" style="margin-left:8px; color:#fff; background:orange; border:none; border-radius:4px; padding:2px 8px; font-size:12px; text-decoration:none; display:inline-block;">Update</a>';
echo '</div>';
                    echo '<div>' . nl2br(htmlspecialchars($comment['contenu_commentaire'])) . '</div>';
                    if (!empty($comment['image_commentaire'])) {
                        echo '<div style="margin-top:6px;"><img src="data:image/jpeg;base64,' . base64_encode($comment['image_commentaire']) . '" alt="Comment Image" style="max-width:100px; max-height:100px; border-radius:6px;"></div>';
                    }
                    echo '</div>';
                }
            } else {
                echo '<div style="font-size: 13px; color: #555; margin-bottom: 6px;">No comments yet.</div>';
            }
            echo '</div>';
            // Add Comment Button
            echo '<a href="../gestion_comment/add_comment.php?id_blog=' . $blogId . '" class="btn btn-warning" style="margin-bottom: 10px; background: orange; color: #fff; border: none; border-radius: 20px; padding: 6px 18px; font-size: 14px;">Add Comment</a>';
            // Comment Modal
            echo '<div id="comment-modal-' . $blogId . '" class="modal" style="display:none; position:fixed; z-index:9999; left:0; top:0; width:100%; height:100%; overflow:auto; background-color:rgba(0,0,0,0.4);">';
            echo '<div class="modal-content" style="background:#fff; margin:10% auto; padding:20px; border:1px solid #888; width:80%; max-width:400px; border-radius: 12px;">';
            echo '<span onclick="document.getElementById(\'comment-modal-' . $blogId . '\').style.display=\'none\'" class="close" style="float:right; font-size:28px; font-weight:bold; cursor:pointer;">&times;</span>';
            echo '<form action="../gestion_comment/add_comment.php" method="post" enctype="multipart/form-data">';
            echo '<input type="hidden" name="id_blog" value="' . $blogId . '">';
            echo '<div class="form-group">';
            echo '<label for="contenu_commentaire">Comment</label>';
            echo '<div style="position: relative;">';
            echo '<textarea name="contenu_commentaire" class="form-control" required></textarea>';
            echo '<button type="button" style="position: absolute; right: 10px; top: 10px; background: none; border: none; cursor: pointer;" title="Voice Recording">';
            echo '<i class="fa fa-microphone" style="font-size: 20px; color: #666;"></i>';
            echo '</button>';
            echo '</div>';
            echo '</div>';
            echo '<div class="form-group">';
            echo '<label for="image_commentaire">Image (optional)</label>';
            echo '<input type="file" name="image_commentaire" accept="image/*">';
            echo '</div>';
            echo '<button type="submit" class="btn btn-success">Submit</button>';
            echo '<button type="button" class="btn btn-secondary" onclick="document.getElementById(\'comment-modal-' . $blogId . '\').style.display=\'none\'">Cancel</button>';
            echo '</form>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
    }

    public function countBlogsByType()
    {
        $sql = "SELECT type_blog, COUNT(*) as count FROM $this->tab_name GROUP BY type_blog";
        $db = config::getConnexion();
        try {
            $stmt = $db->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }
}

?>