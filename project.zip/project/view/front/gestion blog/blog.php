<!doctype html>
<html class="no-js" lang="en">
	<head>
		<!-- META DATA -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Rufina:400,700" rel="stylesheet" />
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet" />

		<!-- TITLE OF SITE -->
		<title>Travel Blog</title>

		<!-- favicon img -->
		<link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>

		<!--font-awesome.min.css-->
		<link rel="stylesheet" href="assets/css/font-awesome.min.css" />

		<!--animate.css-->
		<link rel="stylesheet" href="assets/css/animate.css" />

		<!--hover.css-->
		<link rel="stylesheet" href="assets/css/hover-min.css">

		<!--datepicker.css-->
		<link rel="stylesheet"  href="assets/css/datepicker.css" >

		<!--owl.carousel.css-->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
		<link rel="stylesheet" href="assets/css/owl.theme.default.min.css"/>

		<!-- range css-->
        <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />

		<!--bootstrap.min.css-->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" />

		<!-- bootsnav -->
		<link rel="stylesheet" href="assets/css/bootsnav.css"/>

		<!--style.css-->
		<link rel="stylesheet" href="assets/css/style.css" />

		<!--responsive.css-->
		<link rel="stylesheet" href="assets/css/responsive.css" />

		<link rel="stylesheet" href="blog_add_model_style.css">
    </head>

<?php
include '../../../Controller/blog_con.php';

// Création d'une instance du contrôleur des événements
$blogC = new blogCon("blog");

// Récupération de la liste des événements
$blogs = $blogC->listBlogs();

?>


	<body>
		<!-- main-menu Start -->
		<header class="top-area" style="position:fixed;top:0;left:0;width:100%;z-index:1000;background:#393e46;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
			<div class="header-area" style="background:#393e46;">
				<div class="container">
					<div class="row" style="align-items:center;">
						<div class="col-sm-2">
							<div class="logo">
								<a href="index.html" style="color:#00bfff;font-size:24px;font-weight:bold;letter-spacing:1px;">
									TRIP<span style="color:#fff;">PED</span>
								</a>
							</div>
						</div>
						<div class="col-sm-10">
							<div class="main-menu">
								<div class="navbar-header">
									<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
										<i class="fa fa-bars" style="color:#fff;"></i>
									</button>
								</div>
								<div class="collapse navbar-collapse">
									<ul class="nav navbar-nav navbar-right" style="margin-top:0;">
										<li class="smooth-menu"><a href="#home" style="color:#fff;">Home</a></li>
										<li class="smooth-menu"><a href="#gallery" style="color:#fff;">Transport</a></li>
										<li class="smooth-menu"><a href="#gallery" style="color:#fff;">Tours</a></li>
										<li class="smooth-menu"><a href="#spo" style="color:#fff;">Accommodation</a></li>
										<li class="smooth-menu"><a href="blog.php" style="color:#fff;">Blog</a></li>
										<li class="smooth-menu"><a href="#subs" style="color:#fff;">Subscription</a></li>
										<li>
											<button class="book-btn" style="background:#00bfff;color:#fff;border:none;padding:6px 18px;border-radius:4px;margin-left:10px;">Book Now</button>
										</li>
										<li>
											<a href="../../back/gestion blog/gestion_blog.php" class="btn btn-primary" style="background:#222e3c;color:#fff;margin-left:10px;border:none;">Go To Back Office</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="home-border" style="border-bottom:2px solid #fff;"></div>
				</div>
			</div>
		</header>
		<div style="height:90px;"></div>
		<!-- main-menu End -->

		<!-- Hero-area -->
		<div class="hero-area section">

			<!-- Backgound Image -->

			<!-- /Backgound Image -->

			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1 text-center">
						<ul class="hero-area-tree">
							<li><a href="index.html">Home</a></li>
							<li>Blog</li>
						</ul>
						<h1 class="white-text">Blog Page</h1>

					</div>
				</div>
			</div>

		</div>
		<!-- /Hero-area -->

		<!-- Blog -->
		<div id="blog" class="section">


			<div id="id01" class="modal">
		
				<span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
				
				<form class="modal-content" role="form text-left" action="add_blog_front.php" method="post" enctype="multipart/form-data">
				
					<div class="container">
					
								<h1>Ajout</h1>
								<p>Formulaire d'ajout de blog</p>
								<hr>

								<label for="nom"><b>Nom</b></label>
								<input type="text" placeholder="Enter Nom" name="nom" id="nom" required>
								<div id="nomError" style="color: red;"></div>

								<label for="image_blog"><b>Image</b></label>
								<input type="file" id="image_blog" name="image_blog" accept="image/*" class="form-input"  require/>
								<div id="image_blogError" style="color: red;"></div>

								<label for="type"><b>type</b></label>
								<select id="type" name="type" required>
								<option value="" selected disabled>Choose travel type</option>
								<option value="Adventure Travel">Adventure Travel</option>
								<option value="Cultural Tourism">Cultural Tourism</option>
								<option value="Beach Vacation">Beach Vacation</option>
								<option value="City Break">City Break</option>
								<option value="Eco Tourism">Eco Tourism</option>
								<option value="Luxury Travel">Luxury Travel</option>
								<option value="Road Trip">Road Trip</option>
								<option value="Backpacking">Backpacking</option>
								</select>
								<div id="typeError" style="color: red;"></div>

								<label for="description"><b>Description</b></label>
								<textarea placeholder="Enter description" name="description" id="description" cols="30" rows="10" class="form-textarea" required></textarea>
								<div id="descriptionError" style="color: red;"></div>
								<hr>

						<div class="clearfix">
							<input type="submit" class="cancelbtn" name="addbtn" id="addbtn" value="Add" onclick="return verif_blog_add()">
							<button type="button" class="deletebtn" onclick="document.getElementById('id01').style.display='none'">Cancel</button>
						</div>

					</div>

				</form>
				
			</div>
			

			<!-- container -->
			<div class="container">

				<input onclick="document.getElementById('id01').style.display='block'" type="button" class="btn bg-gradient-dark w-100 my-4 mb-2" name="addbtn" id="addbtn" value="Ajout +" onclick="return verif_blog_update()" style="background-color: orange; color: white; margine: 15px;">

				<!-- row -->
				<div class="row">

					<!-- main blog -->
					<div id="main" class="col-md-9">

						<!-- generate blogs -->
						<div class="row" id="blog-list">
							<?php $blogC->generateBlogs($blogs);?>
						</div>
					</div>
					<!-- /generate blogs -->
						
						
						<!-- /row -->
					</div>
					<!-- /main blog -->

					<!-- aside blog -->
					<div id="aside" class="col-md-3">

						<!-- search widget -->
						<div class="widget search-widget">
							<form>
								<input class="input" type="text" name="search">
								<button><i class="fa fa-search"></i></button>
							</form>
						</div>
						<!-- /search widget -->

					</div>
					<!-- /aside blog -->

				</div>
				<!-- row -->

			</div>
			<!-- container -->

		</div>
		<!-- /Blog -->




		<!-- footer-copyright start -->
		<footer  class="footer-copyright">
			<div class="container">
				<div class="footer-content">
					<div class="row">
						<div class="col-sm-3">
							<div class="single-footer-item">
								<div class="footer-logo">
									<a href="index.html">
										TRIP<span>PED</span>
									</a>
									<p>
										best travel agency
									</p>
								</div>
							</div><!--/.single-footer-item-->
						</div><!--/.col-->

						<div class="col-sm-3">
							<div class="single-footer-item">
								<h2>link</h2>
								<div class="single-footer-txt">
									<p><a href="#">home</a></p>
									<p><a href="#">Transport</a></p>
									<p><a href="#">Tours</a></p>
									<p><a href="#">Accommodation</a></p>
									<p><a href="#">Blog</a></p>
									<p><a href="#">contacts</a></p>
								</div><!--/.single-footer-txt-->
							</div><!--/.single-footer-item-->
						</div><!--/.col-->

						<div class="col-sm-3">
							<div class="single-footer-item">
								<h2>popular destination</h2>
								<div class="single-footer-txt">
									<p><a href="#">china</a></p>
									<p><a href="#">venezuela</a></p>
									<p><a href="#">brazil</a></p>
									<p><a href="#">australia</a></p>
									<p><a href="#">london</a></p>
								</div><!--/.single-footer-txt-->
							</div><!--/.single-footer-item-->
						</div><!--/.col-->

						<div class="col-sm-3">
							<div class="single-footer-item text-center">
								<h2 class="text-left">contacts</h2>
								<div class="single-footer-txt text-left">
									<p>+216 71 234 567 </p>
									<p class="foot-email"><a href="#"> contact@tripped.com </a></p>
									<p>North Warnner Park 336/A</p>
									<p>Newyork, USA</p>
								</div><!--/.single-footer-txt-->
							</div><!--/.single-footer-item-->
						</div><!--/.col-->

					</div><!--/.row-->

				</div><!--/.footer-content-->
				<hr>
				<div class="foot-icons ">
					<ul class="footer-social-links list-inline list-unstyled">
		                <li><a href="#" target="_blank" class="foot-icon-bg-1"><i class="fa fa-facebook"></i></a></li>
		                <li><a href="#" target="_blank" class="foot-icon-bg-2"><i class="fa fa-twitter"></i></a></li>
		                <li><a href="#" target="_blank" class="foot-icon-bg-3"><i class="fa fa-instagram"></i></a></li>
		        	</ul>
		        	<p>&copy; 2017 <a href="https://www.themesine.com">ThemeSINE</a>. All Right Reserved</p>

		        </div><!--/.foot-icons-->
				<div id="scroll-Top">
					<i class="fa fa-angle-double-up return-to-top" id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
				</div><!--/.scroll-Top-->
			</div><!-- /.container-->

		</footer><!-- /.footer-copyright-->
		<!-- footer-copyright end -->

		<script src="assets/js/jquery.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->

		<!--modernizr.min.js-->
		<script  src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>

		<!--bootstrap.min.js-->
		<script  src="assets/js/bootstrap.min.js"></script>

		<!-- bootsnav js -->
		<script src="assets/js/bootsnav.js"></script>

		<!-- jquery.filterizr.min.js -->
		<script src="assets/js/jquery.filterizr.min.js"></script>

		<script  src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>

		<!--jquery-ui.min.js-->
        <script src="assets/js/jquery-ui.min.js"></script>

        <!-- counter js -->
		<script src="assets/js/jquery.counterup.min.js"></script>
		<script src="assets/js/waypoints.min.js"></script>

		<!--owl.carousel.js-->
        <script  src="assets/js/owl.carousel.min.js"></script>

        <!-- jquery.sticky.js -->
		<script src="assets/js/jquery.sticky.js"></script>

        <!--datepicker.js-->
        <script  src="assets/js/datepicker.js"></script>

		<!--Custom JS-->
		<script src="assets/js/custom.js"></script>

		<!-- Blog specific JS -->
		<script src="../../../js/blogs/blog_js.js"></script>

		<!-- Comment validation JS -->
		<script src="../../../js/comments/comment_js.js"></script>

	</body>
</html>

<style>
#blog-list .single-blog {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 24px rgba(0,0,0,0.08);
    margin-bottom: 32px;
    padding: 0;
    overflow: hidden;
    transition: box-shadow 0.3s;
    display: flex;
    flex-direction: column;
    min-height: 420px;
}
#blog-list .single-blog:hover {
    box-shadow: 0 8px 32px rgba(0,0,0,0.16);
}
#blog-list .blog-img {
    width: 100%;
    height: 220px;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f7f7f7;
}
#blog-list .blog-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-bottom: 1px solid #eee;
}
#blog-list h4 {
    font-size: 1.3rem;
    font-weight: 600;
    margin: 18px 18px 8px 18px;
    color: #222;
}
#blog-list p {
    margin: 0 18px 18px 18px;
    color: #555;
    font-size: 1rem;
    min-height: 60px;
}
#blog-list .blog-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 0 18px 18px 18px;
    font-size: 0.95rem;
    color: #888;
}
#blog-list .blog-meta-author a {
    color: #ff6700;
    font-weight: 500;
}
#blog-list .btn.btn-primary {
    background: #ff6700;
    border: none;
    margin: 0 18px 18px 18px;
    border-radius: 6px;
    padding: 8px 18px;
    font-size: 1rem;
    transition: background 0.2s;
}
#blog-list .btn.btn-primary:hover {
    background: #e65c00;
}
@media (max-width: 991px) {
    #main.col-md-9 {
        width: 100%;
        max-width: 100%;
    }
    #blog-list .single-blog {
        min-height: 340px;
    }
}
</style>
