<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Comment</title>
    <link rel="stylesheet" href="../gestion blog/blog_add_model_style.css">
</head>
<body>
<div id="idAddModal" class="modal" style="display:block;">
    <span onclick="window.location.href='../gestion blog/blog.php'" class="close" title="Close Modal">&times;</span>
    <form id="commentForm" class="modal-content" action="" method="post" enctype="multipart/form-data">
        <div class="container">
            <h1>Add Comment</h1>
            <p>Fill in your comment below</p>
            <hr>
            <input type="hidden" name="id_blog" value="<?php echo isset($_GET['id_blog']) ? htmlspecialchars($_GET['id_blog']) : ''; ?>">
            <label for="contenu_commentaire"><b>Content</b></label>
            <textarea name="contenu_commentaire" id="contenu_commentaire" cols="30" rows="5"></textarea>
            <div id="contenu_commentaireError" style="color:red;"></div>
            <label for="image_commentaire"><b>Image</b></label>
            <input type="file" id="image_commentaire" name="image_commentaire" accept="image/*" class="form-input" />
            <div id="image_commentaireError" style="color:red;"></div>
            <hr>
            <div class="clearfix">
                <input type="submit" class="cancelbtn" name="addbtn" id="addbtn" value="Add" style="background-color: orange; color: white;">
                <button type="button" class="deletebtn" onclick="window.location.href='../gestion blog/blog.php'">Cancel</button>
            </div>
            <?php if (!empty($error)): ?>
                <div style="color:red;"> <?php echo $error; ?> </div>
            <?php endif; ?>
        </div>
    </form>
</div>
</body>
</html>
<script src="../../../js/comments/comment_js.js"></script>
<?php
session_start();
include_once '../../../config.php';
include '../../../Controller/comment_con.php';
include '../../../Model/comment.php';
$commentC = new CommentCon("commentaire");
$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["id_blog"]) && isset($_POST["contenu_commentaire"])) {
        if (!empty($_POST['id_blog']) && !empty($_POST["contenu_commentaire"])) {
            // Bad words filter
            $badWords = ["bitch", "hoe", "simp", "idiot", "stupid", "dumb", "fool", "moron", "loser", "jerk", "bastard", "asshole", "shit", "crap", "damn", "hell", "bitch", "slut", "whore", "dick", "cock", "piss", "fuck", "fucking", "fucker", "motherfucker", "cunt", "twat", "prick", "wanker", "bollocks", "bugger", "arse", "arsehole", "jackass", "retard", "retarded", "suck", "sucks", "sucker", "pussy", "tit", "boob", "boobs", "nigger", "nigga", "spic", "chink", "gook", "kike", "fag", "faggot", "dyke", "tranny", "queer", "homo", "gay", "lesbo", "slutty", "bastards", "shithead", "shitface", "douche", "douchebag", "scumbag", "skank", "cum", "jizz", "spunk", "balls", "nuts", "testicle", "penis", "vagina", "anus", "butt", "butthole", "craphead", "shitbag", "shitass", "fuckface", "fuckhead", "asswipe", "asshat", "dipshit", "twit", "twithead", "twatwaffle", "dickhead", "dickweed", "pisshead", "pissface", "cockhead", "cockface", "cockbite", "cockmunch", "cocksmoker", "cumdumpster", "cumslut", "cumwhore", "cumface", "cumshot"]; // Add your bad words here
            $contentLower = strtolower($_POST['contenu_commentaire']);
            $foundBadWord = false;
            foreach ($badWords as $word) {
                if (strpos($contentLower, $word) !== false) {
                    $foundBadWord = true;
                    break;
                }
            }
            if ($foundBadWord) {
                $error = "Your comment contains inappropriate language.";
            } else {
                try {
                    $date_commentaire = date('Y-m-d');
                    $image_commentaire = '';
                    if (isset($_FILES['image_commentaire']) && $_FILES['image_commentaire']['error'] === UPLOAD_ERR_OK) {
                        $image_commentaire = file_get_contents($_FILES['image_commentaire']['tmp_name']);
                    }
                    $comment = new Commentaire(
                        '',
                        $_POST['id_blog'],
                        $image_commentaire,
                        $_POST['contenu_commentaire'],
                        $date_commentaire
                    );
                    if ($commentC->addComment($comment)) {
                        header('Location: ../gestion blog/blog.php');
                        exit();
                    } else {
                        $error = "Failed to add comment.";
                    }
                } catch (Exception $e) {
                    $error = $e->getMessage();
                }
            }
        } else {
            $error = "All fields are required.";
        }
    }
}
?>
if (!empty($error)) {
    echo "<div class='error'>$error</div>";
}
?>
<!-- Include JS validation -->
<script src="../../../js/comments/comment_js.js"></script>