<?php
session_start();
include_once '../../../config.php';
include '../../../Controller/comment_con.php';
include '../../../Model/comment.php';

$commentC = new CommentCon("commentaire");
$error = "";
$comment = null;

if (isset($_GET['id'])) {
    $current_id = $_GET['id'];
    // Fetch the comment to pre-fill the form
    $db = config::getConnexion();
    $stmt = $db->prepare("SELECT * FROM commentaire WHERE id_commentaire = :id");
    $stmt->execute(['id' => $current_id]);
    $comment_data = $stmt->fetch();
    if (!$comment_data) {
        $error = "Comment not found.";
    }
} else {
    $error = "No comment ID provided.";
}

if (
    isset($_POST["id_blog"]) &&
    isset($_POST["contenu_commentaire"])
) {
    if (
        !empty($_POST['id_blog']) &&
        !empty($_POST["contenu_commentaire"])
    ) {
        // Bad words filter
        $badWords = ["bitch", "hoe", "simp", "idiot", "stupid", "dumb", "fool", "moron", "loser", "jerk", "bastard", "asshole", "shit", "crap", "damn", "hell", "bitch", "slut", "whore", "dick", "cock", "piss", "fuck", "fucking", "fucker", "motherfucker", "cunt", "twat", "prick", "wanker", "bollocks", "bugger", "arse", "arsehole", "jackass", "retard", "retarded", "suck", "sucks", "sucker", "pussy", "tit", "boob", "boobs", "nigger", "nigga", "spic", "chink", "gook", "kike", "fag", "faggot", "dyke", "tranny", "queer", "homo", "gay", "lesbo", "slutty", "bastards", "shithead", "shitface", "douche", "douchebag", "scumbag", "skank", "cum", "jizz", "spunk", "balls", "nuts", "testicle", "penis", "vagina", "anus", "butt", "butthole", "craphead", "shitbag", "shitass", "fuckface", "fuckhead", "asswipe", "asshat", "dipshit", "twit", "twithead", "twatwaffle", "dickhead", "dickweed", "pisshead", "pissface", "cockhead", "cockface", "cockbite", "cockmunch", "cocksmoker", "cumdumpster", "cumslut", "cumwhore", "cumface", "cumshot"];
        $contentLower = strtolower($_POST['contenu_commentaire']);
        $foundBadWord = false;
        foreach ($badWords as $word) {
            if (strpos($contentLower, $word) !== false) {
                $foundBadWord = true;
                break;
            }
        }
        if ($foundBadWord) {
            $error = "Your comment contains inappropriate language.";
        } else {
            try {
                $date_commentaire = date('Y-m-d');
                $image_commentaire = '';
                if (isset($_FILES['image_commentaire']) && $_FILES['image_commentaire']['error'] === UPLOAD_ERR_OK) {
                    $image_commentaire = file_get_contents($_FILES['image_commentaire']['tmp_name']);
                } else if (isset($comment_data['image_commentaire'])) {
                    $image_commentaire = $comment_data['image_commentaire'];
                }
                $comment = new Commentaire(
                    $current_id,
                    $_POST['id_blog'],
                    $image_commentaire,
                    $_POST['contenu_commentaire'],
                    $date_commentaire
                );
                if ($commentC->updateComment($comment)) {
                    header('Location: ../gestion blog/blog.php');
                    exit();
                } else {
                    $error = "Failed to update comment";
                }
            } catch (Exception $e) {
                $error = "Error: " . $e->getMessage();
            }
        }
    } else {
        $error = "Missing information";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Comment</title>
    <link rel="stylesheet" href="../gestion blog/blog_add_model_style.css">
</head>
<body>
<div id="idUpdateModal" class="modal" style="display:block;">
    <span onclick="window.location.href='../gestion blog/blog.php'" class="close" title="Close Modal">&times;</span>
    <form id="commentForm" class="modal-content" action="" method="post" enctype="multipart/form-data">
        <div class="container">
            <h1>Update Comment</h1>
            <p>Update your comment below</p>
            <hr>
            <input type="hidden" name="id_blog" value="<?php echo htmlspecialchars($comment_data['id_blog'] ?? ''); ?>">
            <label for="contenu_commentaire"><b>Content</b></label>
            <textarea name="contenu_commentaire" id="contenu_commentaire" cols="30" rows="5"><?php echo htmlspecialchars($comment_data['contenu_commentaire'] ?? ''); ?></textarea>
            <div id="contenu_commentaireError" style="color:red;"></div>
            <label for="image_commentaire"><b>Image</b></label>
            <input type="file" id="image_commentaire" name="image_commentaire" accept="image/*" class="form-input" />
            <div id="image_commentaireError" style="color:red;"></div>
            <?php if (!empty($comment_data['image_commentaire'])): ?>
                <div><img src="data:image/jpeg;base64,<?php echo base64_encode($comment_data['image_commentaire']); ?>" alt="Current Image" style="max-width:100px;max-height:100px;" /></div>
            <?php endif; ?>
            <hr>
            <div class="clearfix">
                <input type="submit" class="cancelbtn" name="updatebtn" id="updatebtn" value="Update" style="background-color: orange; color: white;">
                <button type="button" class="deletebtn" onclick="window.location.href='../gestion blog/blog.php'">Cancel</button>
            </div>
            <?php if (!empty($error)): ?>
                <div style="color:red;"> <?php echo $error; ?> </div>
            <?php endif; ?>
        </div>
    </form>
</div>
</body>
</html>
<script src="../../../js/comments/comment_js.js"></script>